import { defineTool } from '@deepseek-ai/dsh-tools'

export const widget = defineTool({
  name: 'widget.read',
  description: 'Read a synthetic widget record. Read-only.',
})
