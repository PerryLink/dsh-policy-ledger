# @synthetic/widget

Synthetic test package. No real code, no network, no install script.
